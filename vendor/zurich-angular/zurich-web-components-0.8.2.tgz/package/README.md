# @zurich/web-components

<p align="center">
  <a href="https://npmjs.com/package/@zurich/web-components">
    <img
      src="https://img.shields.io/npm/v/@zurich/web-components?style=for-the-badge&color=yellow&label=npm%20version&logo=npm"
      alt="npm package"
    >
  </a>
  &nbsp;
  &nbsp;
  <a href="https://npmjs.com/package/@zurich/web-components">
    <img
      src="https://img.shields.io/npm/dm/@zurich/web-components?style=for-the-badge&color=white&label=npm%20downloads&logo=npm"
      alt="npm downloads"
    >
  </a>
<p>

<p align="center">
  <b>Made for:</b>
</p>

<p align="center">
  <a href="https://reactjs.dev/" target="_blank">
    <img src="https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB" alt="React"/>
  </a>
  <a href="https://nextjs.org/" target="_blank">
    <img src="https://img.shields.io/badge/Next.js-black?style=for-the-badge&logo=next.js&logoColor=white" alt="Next.js"/>
  </a>
  <a href="https://vuejs.org/" target="_blank">
    <img src="https://img.shields.io/badge/Vue.js-35495E?style=for-the-badge&logo=vuedotjs&logoColor=4FC08D" alt="Vue"/>
  </a>
  <img src="https://img.shields.io/badge/HTML-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white" alt="HTML"/>
  <img src="https://img.shields.io/badge/CSS-1572B6?style=for-the-badge&logo=css3&logoColor=fff" alt="CSS"/>
</p>

## About

`@zurich/web-components` provides a collection of reusable Web Components built with [Lit](https://lit.dev/) for the Zurich Design System (ZDS). These components work with any JavaScript framework or vanilla HTML/CSS.

### Features

  - **Framework agnostic**: Works with React, Vue, Angular, or plain HTML
  - **Standalone mode**: No external CDN required - all assets embedded (v0.8.0+)
  - **TypeScript support**: Full type definitions included
  - **Accessible**: Built with accessibility in mind
  - **Themeable**: Supports light and dark themes

## Installation

```bash
npm install @zurich/web-components
```

## Available Components

The package includes 100+ components organized into categories:

  - **Atoms**: Button, Icon, Badge, Tag, Shape, Image, Loader, etc.
  - **Inputs**: TextInput, Select, Checkbox, Switch, DateInput, NumberInput, etc.
  - **Molecules**: Card, Alert, Modal, Tooltip, Avatar, Breadcrumbs, etc.
  - **Layouts**: Accordion, Tabs, Table, Carousel, Sidebar, etc.
  - **Data**: Charts (Bar, Line, Pie, Donut, etc.), KPI displays
  - **Organisms**: Navigation, Footer, CookiesConsent, etc.

All React wrappers use the `Zr` prefix (e.g., `ZrButton`, `ZrTextInput`).

## ZDS Ecosystem

This package is part of the [Zurich Design System (ZDS)](https://www.npmjs.com/search?q=%40zurich%20ZDS) NPM packages:

  - [`@zurich/design-tokens`](https://www.npmjs.com/package/@zurich/design-tokens) - Design tokens, CSS variables, icons, and fonts
  - [`@zurich/css-components`](https://www.npmjs.com/package/@zurich/css-components) - CSS-only component styles with React/Vue helpers
  - [`@zurich/web-components`](https://www.npmjs.com/package/@zurich/web-components) - Web Components (Lit-based)
  - [`@zurich/angular-components`](https://www.npmjs.com/package/@zurich/angular-components) - Angular component wrappers
  - [`@zurich/dev-utils`](https://www.npmjs.com/package/@zurich/dev-utils) - Development utilities and tooling

## License

[![NPM License](https://img.shields.io/npm/l/@zurich/web-components?style=for-the-badge&logo=cachet&logoColor=fff)](http://opensource.org/licenses/ISC)

___

Made with 💙 by Pablo Pérez Chueca and Traian Constantin Dida
for <a href="https://www.zurich.com/" target="_blank">Zurich Insurance Company</a>.
