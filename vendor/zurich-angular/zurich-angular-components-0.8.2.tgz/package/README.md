# @zurich/angular-components

<p align="center">
  <a href="https://npmjs.com/package/@zurich/angular-components">
    <img
      src="https://img.shields.io/npm/v/@zurich/angular-components?style=for-the-badge&color=yellow&label=npm%20version&logo=npm"
      alt="npm package"
    >
  </a>
  &nbsp;
  &nbsp;
  <a href="https://npmjs.com/package/@zurich/angular-components">
    <img
      src="https://img.shields.io/npm/dm/@zurich/angular-components?style=for-the-badge&color=white&label=npm%20downloads&logo=npm"
      alt="npm downloads"
    >
  </a>
<p>

<p align="center">
  <b>Made for:</b>
</p>

<p align="center">
  <a href="https://angular.dev/" target="_blank">
    <img src="https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white" alt="Angular"/>
  </a>
  <img src="https://img.shields.io/badge/HTML-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white" alt="HTML"/>
  <img src="https://img.shields.io/badge/CSS-1572B6?style=for-the-badge&logo=css3&logoColor=fff" alt="CSS"/>
</p>

## About

`@zurich/angular-components` provides Angular-specific wrappers for ZDS Web Components.
These wrappers offer proper Angular integration with two-way binding, form control support,
and TypeScript definitions.

### Features

  - **Angular integration**: Proper Angular bindings for all ZDS components
  - **Form support**: Works with Angular Reactive Forms and Template-driven forms
  - **Two-way binding**: Full `[(ngModel)]` support
  - **TypeScript**: Complete type definitions
  - **Standalone mode**: No external CDN required (v0.8.0+)

## Installation

```bash
npm install @zurich/angular-components
```

## Usage

### Standalone Components (Angular 17+)

All components are Angular standalone components with the `Za` prefix:

```typescript
// app.component.ts
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ZaButton, ZaTextInput } from '@zurich/angular-components';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ZaButton, ZaTextInput],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  template: `
    <za-text-input [(ngModel)]="name" label="Name"></za-text-input>
    <za-button (click)="submit()">Submit</za-button>
  `
})
export class AppComponent {
  name = '';
  submit() { console.log(this.name); }
}
```

### Styles

Import the required styles in your `angular.json` or main styles file:

```scss
// styles.scss
@import '@zurich/design-tokens/dist/index.css';
```

## Available Components

All ZDS components are available with the `za-` prefix in templates:

  - `za-button`, `za-badge`, `za-tag`, `za-icon`
  - `za-text-input`, `za-select`, `za-checkbox`, `za-radio-select`
  - `za-card`, `za-alert`, `za-modal`, `za-tooltip`
  - And many more...

Import the corresponding `Za` prefixed class (e.g., `ZaButton`, `ZaTextInput`).

## ZDS Ecosystem

This package is part of the [Zurich Design System (ZDS)](https://www.npmjs.com/search?q=%40zurich%20ZDS):

  - [`@zurich/design-tokens`](https://www.npmjs.com/package/@zurich/design-tokens)
  - [`@zurich/css-components`](https://www.npmjs.com/package/@zurich/css-components)
  - [`@zurich/web-components`](https://www.npmjs.com/package/@zurich/web-components)
  - [`@zurich/angular-components`](https://www.npmjs.com/package/@zurich/angular-components)
  - [`@zurich/dev-utils`](https://www.npmjs.com/package/@zurich/dev-utils)

## License

[![NPM License](https://img.shields.io/npm/l/@zurich/angular-components?style=for-the-badge&logo=cachet&logoColor=fff)](http://opensource.org/licenses/ISC)

___

Made with 💙 by Pablo Pérez Chueca and Traian Constantin Dida
for <a href="https://www.zurich.com/" target="_blank">Zurich Insurance Company</a>.
